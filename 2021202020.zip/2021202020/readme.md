To Compile: g++ main.cpp
To Run: ./a.out

'~': locates to the start position of Application as clarified in Queries Forum in MS Teams
Home folder (the folder where the application was started) as Mentioned in PDF

Normal Mode Features/Commands that can be used
'h': Takes you to Home
'Up Arrow': Move up in directory lists
'Down Arrow': Move down in directory list
'l': Scroll Down in case of Vertical Overflow
'k': Scroll Back Up if we came down using 'l'
'Enter': Open File/Folder in Normal mode
':': Activate Command Mode
'q': Exit
'Left Arrow': Go Back
'Right Arrow': Go Forward
'Backspace': Go one level Up

Command Mode Features/Commands that can be used
copy <source_file(s)> <destination_directory>
copy <source_directory(s)> <destination_directory>
move <source_file(s)> <destination_directory>
move <source_directory(s)> <destination_directory>
rename <old_filename> <new_filename>
create_file <file_name> <destination_path>
create_dir <dir_name> <destination_path>
delete_file <file_path>
delete_dir <dir_path>
goto <directory_path>
search <file_name>
search <directory_name>
'ESC': Application should go back to Normal Mode
'q': Application should close
Note: Typing Wrong Input Command or copying/moving/renaming files which does not exists Terminates the program, so make sure to check what has been typed before proceeding.

In Command Mode While Typing Command, user can also  Type 'Backspace' to erase previously typed Command
The Program has the ability to handle Files/Folder with Names containing blank spaces (Use Escape Sequences in Input to Try)

Copy and Move command will work even if destination directory doesnot exists.


The Program has capability to handle Window resize

Incase of Horizontal Overflow, information is truncated but they can be viewed by Horizontal scrolling, the same way we were dealing with vertical Overflow for that additional Feature/Commands has been added (Refer Below)

Additional Feature:
1)  '[': Move Cursor Left one place at a time. 
2)  ']': Move Cursor Right one place at a time.

So, when we have a case when information is too lager to be displayed on screen , then we can move right on screen to see that information.

But moving one alphabet at a time can take some effort. So press
3)  'End': to move to last character of current line.
4)  'Home': to come back top start (1st character) of current line.

I have added similar feature for Vertical Overflow, Moving cursor down and up one by one can take some effort, so press 
5)  'Page DN': To scroll down by 'x' Lines
6)  'Page UP': To scroll up by 'x' Lines

x is number of lines that can be printed on screen.

as per Requirement analysis 'k' & 'l' takes care of vertical overflow & UP & Down Arrow takes care of moving cursor UP & Down on the visible region of Screen, i.e. UP or Down arrow are not supposed to take care of vertical Overflow, So I have added

7)  '+': Which can move cursor Down as well as scroll Down
8)  '-': Which can move cursor Up as well as scroll Up

The Program is well tested and it seems to fullfill all the requirements on my system, bugs may come depending on the system and on failure of certain system calls such as ioctl although failsafe method is provided but this program cannot be proved to work always.

I Tried to Deliver full fledged Application (which also satisfies Requirement analysis of assignment) from my Side: In case of bug Contact me.